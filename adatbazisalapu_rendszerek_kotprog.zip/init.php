<?php 

require_once("classes/Db.php");
require_once("classes/User.php");
require_once("functions.php");
require_once("classes/Legitarsasag.php");
require_once("classes/Repuloter.php");
require_once("classes/Poggyasz.php");
require_once("classes/Jegy.php");
ob_start();
session_start();