<?php
require_once("init.php");

template_header("Kezdőlap");
navbar();
searchBox();
template_footer();